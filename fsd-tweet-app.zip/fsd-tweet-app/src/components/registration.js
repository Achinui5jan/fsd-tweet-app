import React, { useState } from 'react';
import validation from './validation';
import { Link } from 'react-router-dom';

const Registration = () => {

    const [userRegistration, setUserRegistration] = useState({
        firstName: "",
        lastName: "",
        email: "",
        loginId: "",
        password: "",
        confirmPassword: "",
        contactNumber: ""
    });

    const [errors, setErrors] = useState({});

    const handleRegistration = (e) => {
        e.preventDefault();
        const name = e.target.name;
        const value = e.target.value;
        console.log(name, value);
        setUserRegistration({ ...userRegistration, [name]: value })
    }

    const submitRegistration = async (e) => {
        e.preventDefault();
        setErrors(validation(userRegistration));
        if (errors.allValid) {
            const newData = ({ ...userRegistration, id: new Date().getTime().toString() });
            const checkData = await fetch("http://localhost:8000/registration");
            const data = await checkData.json();
            const user = data.find((x) => {
                if (x.email === userRegistration.email) {

                    setErrors({ err: '(' + x.email + ') already exist try with another mail id' });
                    return true;
                } if (x.loginId === userRegistration.loginId) {

                    setErrors({ err: '(' + x.loginId + ') already exist try with another user id' });
                    return true;
                }

                return false;
            })
            console.log(user);
            if (user === undefined) {
                await fetch("http://localhost:8000/registration", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify(newData)
                }).then(res => {
                    console.log("response: ", res);
                    setErrors({ res: "Welcome to Tweet World: User your LoginId and Password and start tweeting." });

                }).catch(err => {
                    console.log("errror: ", err);
                });
            }
        }

    }
    return (
        <div className="container">
            <div className={!errors.res ? ' alert alert-danger d-none' : 'alert alert-success d-block'} role="alert" >
                {errors.res} <Link to="../">Login</Link>
            </div>
            <div className={!errors.err ? ' alert alert-danger d-none' : 'alert alert-danger d-block'} role="alert" >
                {errors.err}
            </div>
            <form action="" onSubmit={submitRegistration} className={!errors.res ? 'd-block form-signin ' : 'alert alert-success d-none'}>
                <div className="mb-3 ">
                    <label htmlFor="firstName" className="form-label">First Name</label>
                    <input type="text" className={errors.firstName ? ' form-control is-invalid' : 'form-control '} value={userRegistration.firstName}
                        onChange={handleRegistration} name="firstName" aria-describedby="firstName" />
                    {errors.firstName && <div className="small invalid-feedback"> {errors.firstName}</div>}
                </div>
                <div className="mb-3">
                    <label htmlFor="lastName" className="form-label">Last Name</label>
                    <input type="text" className={errors.lastName ? ' form-control is-invalid' : 'form-control '} value={userRegistration.lastName}
                        onChange={handleRegistration} name="lastName" aria-describedby="lastName" />
                    {errors.lastName && <div className="small invalid-feedback">{errors.lastName}</div>}

                </div>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email address</label>
                    <input type="email" className={errors.email ? ' form-control is-invalid' : 'form-control '} value={userRegistration.email}
                        onChange={handleRegistration} name="email" aria-describedby="email" />
                    {errors.email && <div className="small invalid-feedback">{errors.email}</div>}

                </div>
                <div className="mb-3">
                    <label htmlFor="loginId" className="form-label">Login Id</label>
                    <input type="text" className={errors.loginId ? ' form-control is-invalid' : 'form-control '} value={userRegistration.loginId}
                        onChange={handleRegistration} name="loginId" aria-describedby="loginId" />
                    {errors.loginId && <div className="small invalid-feedback">{errors.loginId}</div>}

                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input type="password" className={errors.password ? ' form-control is-invalid' : 'form-control '} value={userRegistration.password}
                        onChange={handleRegistration} name="password" />
                    {errors.password && <div className="small invalid-feedback">{errors.password}</div>}

                </div>
                <div className="mb-3">
                    <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                    <input type="password" className={errors.confirmPassword ? ' form-control is-invalid' : 'form-control '} value={userRegistration.confirmPassword}
                        onChange={handleRegistration} name="confirmPassword" />
                    {errors.confirmPassword && <div className="small invalid-feedback">{errors.confirmPassword}</div>}

                </div>
                <div className="mb-3">
                    <label htmlFor="contactNumber" className="form-label">Contact Number</label>
                    <input type="tel" className={errors.contactNumber ? ' form-control is-invalid' : 'form-control '} value={userRegistration.contactNumber}
                        onChange={handleRegistration} name="contactNumber" onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }} />
                    {errors.contactNumber && <div className="small invalid-feedback">{errors.contactNumber}</div>}

                </div>
                <button type="submit" className="btn btn-primary" >Submit</button>
            </form>
        </div>
    )
}
export default Registration;