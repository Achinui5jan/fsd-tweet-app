import React, { useState, useEffect } from 'react'
import Nav from './nav'
import { useNavigate } from 'react-router-dom';

const Tweet = () => {
    const navigate = useNavigate();
    const u_id = JSON.parse(localStorage.getItem("user_info"));
    const [userTweets, setuserTweets] = useState({
        user_id: u_id.loginId,
    });
    const [showTweets, setShowTweets] = useState({
        data: []
    });
    const [leftChar, setLeftChar] = useState(144);
    const maxCharLength = 144;
    const handleComments = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        let charCount = maxCharLength - value.length;
        setLeftChar(charCount);
        setuserTweets({ ...userTweets, [name]: value })
    }

    useEffect(() => {
        if (!localStorage.getItem("user_info")) {
            navigate("../", { replace: true });
        }

    }, []);
    useEffect(() => {
        const viewPosts = async (e) => {
            let result = await fetch("http://localhost:8000/Tweets");
            let data = await result.json();
            setShowTweets({ ...showTweets, data })
        }
        viewPosts()
    })

    const handlePosts = async (e) => {
        if (userTweets.comments) {
            const userid = ({ ...userTweets, id: new Date().getTime().toString(), date: new Date().toLocaleDateString(), time: new Date().getHours() + ':' + new Date().getMinutes() });
            const twts = await fetch(`http://localhost:8000/Tweets/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(userid)
            }).then(res => {
                console.log("response: ", res);

            }).catch(err => {
                console.log("errror: ", err);

            });

        }
    }
    const allTweet = showTweets.data.map((res, i) => {
        return (
            <div key={i}>
                <div className="d-flex">

                    <div className="avatar text-center me-2">
                        <div className="rounded-circle bg-warning p-1">

                            <svg width="40" height="40" viewBox="0 0 16 16">
                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                <path d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
                            </svg>
                        </div>

                    </div>
                    <div className="comments-section ms-2 w-100">
                        <strong>{res.user_id}</strong>
                        <div className="form-floating d-flex">
                            <p className="w-100 pt-2">{res.comments}</p>
                            <span className="small text-right text-secondary text-nowrap">{res.date} {res.time}</span>

                        </div>
                        <div className="text-end text-secondary">

                            <div className="d-flex justify-content-end mb-2">
                                <div className="btn-group" role="group" aria-label="Basic example">
                                    <button type="button " className="btn btn-outline-primary rounded-circle border-0  ">
                                        <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                            <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z" />
                                            <path d="M7.066 6.76A1.665 1.665 0 0 0 4 7.668a1.667 1.667 0 0 0 2.561 1.406c-.131.389-.375.804-.777 1.22a.417.417 0 0 0 .6.58c1.486-1.54 1.293-3.214.682-4.112zm4 0A1.665 1.665 0 0 0 8 7.668a1.667 1.667 0 0 0 2.561 1.406c-.131.389-.375.804-.777 1.22a.417.417 0 0 0 .6.58c1.486-1.54 1.293-3.214.682-4.112z" />
                                        </svg>
                                    </button>
                                    <button type="button" className="btn btn-outline-primary  rounded-circle  border-0">
                                        <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                            <path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z" />
                                            <path d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z" />
                                        </svg>
                                    </button>
                                    <button type="button" className="btn btn-outline-primary  rounded-circle  border-0">
                                        <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path d="M11.315 10.014a.5.5 0 0 1 .548.736A4.498 4.498 0 0 1 7.965 13a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .548-.736h.005l.017.005.067.015.252.055c.215.046.515.108.857.169.693.124 1.522.242 2.152.242.63 0 1.46-.118 2.152-.242a26.58 26.58 0 0 0 1.109-.224l.067-.015.017-.004.005-.002zM4.756 4.566c.763-1.424 4.02-.12.952 3.434-4.496-1.596-2.35-4.298-.952-3.434zm6.488 0c1.398-.864 3.544 1.838-.952 3.434-3.067-3.554.19-4.858.952-3.434z" />
                                        </svg>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <hr />
            </div>
        )
    }).reverse();
    return (
        <div className="container ">
            <div className="row">
                <div className="col-12 col-md-4 col-lg-3 col-xl-2">
                    <Nav />
                </div>
                <div className="col-12 col-md-6 middle-body  border border-top-0 border-left border-right border-ligh">
                    <h1 className="h4 my-2" >Welcome: {u_id.loginId} </h1>
                    <hr />
                    {/* comment section */}
                    <div className="d-flex">
                        <div className="avatar">
                            <div className="rounded-circle bg-secondary p-3">
                                <svg width="40" height="40" fill="#fff" viewBox="0 0 16 16">
                                    <path d="M1.5 1a.5.5 0 0 0-.5.5v3a.5.5 0 0 1-1 0v-3A1.5 1.5 0 0 1 1.5 0h3a.5.5 0 0 1 0 1h-3zM11 .5a.5.5 0 0 1 .5-.5h3A1.5 1.5 0 0 1 16 1.5v3a.5.5 0 0 1-1 0v-3a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 1-.5-.5zM.5 11a.5.5 0 0 1 .5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 1 0 1h-3A1.5 1.5 0 0 1 0 14.5v-3a.5.5 0 0 1 .5-.5zm15 0a.5.5 0 0 1 .5.5v3a1.5 1.5 0 0 1-1.5 1.5h-3a.5.5 0 0 1 0-1h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 1 .5-.5z" />
                                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm8-9a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                </svg>
                            </div>
                        </div>
                        <div className="comments-section ms-2 w-100">
                            <div className="form-floating">
                                <textarea className="form-control border-0 w-100" placeholder="Leave a comment here" id="floatingTextarea2"
                                    onChange={handleComments} maxLength="144" name="comments" aria-describedby="comments"
                                ></textarea>
                                <label htmlFor="floatingTextarea2">What are you thinking?</label>
                            </div>
                            <div className="text-end text-secondary">
                                <span className="small">{leftChar} characters are left</span></div>
                            <hr />
                            <div className="d-flex mb-4">
                                <div className="btn-group" role="group" aria-label="Basic example">
                                    <button type="button" className="btn btn-outline-primary rounded-circle border-0">
                                        <svg width="14" height="14" fill="currentColor" className="bi bi-images" viewBox="0 0 16 16">
                                            <path d="M4.502 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
                                            <path d="M14.002 13a2 2 0 0 1-2 2h-10a2 2 0 0 1-2-2V5A2 2 0 0 1 2 3a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v8a2 2 0 0 1-1.998 2zM14 2H4a1 1 0 0 0-1 1h9.002a2 2 0 0 1 2 2v7A1 1 0 0 0 15 11V3a1 1 0 0 0-1-1zM2.002 4a1 1 0 0 0-1 1v8l2.646-2.354a.5.5 0 0 1 .63-.062l2.66 1.773 3.71-3.71a.5.5 0 0 1 .577-.094l1.777 1.947V5a1 1 0 0 0-1-1h-10z" />
                                        </svg>
                                    </button>
                                    <button type="button" className="btn btn-outline-primary  rounded-circle  border-0">
                                        <svg width="14" height="14" fill="currentColor" className="bi bi-image-alt" viewBox="0 0 16 16">
                                            <path d="M7 2.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zm4.225 4.053a.5.5 0 0 0-.577.093l-3.71 4.71-2.66-2.772a.5.5 0 0 0-.63.062L.002 13v2a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4.5l-4.777-3.947z" />
                                        </svg>
                                    </button>

                                </div>
                                <button type="button" className="btn btn-primary rounded-pill ms-auto px-4" onClick={handlePosts}>Tweet</button>

                            </div>

                        </div>
                    </div>
                    <hr />
                    {allTweet}

                </div>
            </div>


        </div>

    )
}

export default Tweet;