const validation = (values) => {
    let errors = { allValid: true };

    if (!values.firstName || !values.firstName.length > 1) {
        errors.firstName = "First Name is required."
        errors.allValid = false;
    }
    if (!values.lastName) {
        errors.lastName = "Last Name is required."
        errors.allValid = false;
    }
    if (!values.email) {
        errors.email = "Email is required"
        errors.allValid = false;
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email is invalid."
        errors.allValid = false;
    }
    if (!values.loginId) {
        errors.loginId = "Login Id is required."
        errors.allValid = false;
    }
    if (!values.password) {
        errors.password = "Password is requrired."
        errors.allValid = false;
    } else if (values.password.length < 6) {
        errors.password = "Password must be more than six characters."
        errors.allValid = false;
    }
    if (!values.confirmPassword) {
        errors.confirmPassword = "Password is requrired."
        errors.allValid = false;
    }
    else if (values.password !== values.confirmPassword) {
        errors.confirmPassword = "Password is not matching."
        errors.allValid = false;
    }
    if (!values.contactNumber) {
        errors.contactNumber = "Enter phone number."
        errors.allValid = false;
    } else if (values.contactNumber.length < 10) {
        errors.contactNumber = "Enter the 10digit phone number."
        errors.allValid = false;
    }
    return errors;

}

export default validation;