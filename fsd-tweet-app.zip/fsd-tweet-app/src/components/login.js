import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
    const [loginId, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    useEffect(() => {
        if (localStorage.getItem("user_info")) {
            navigate("../Tweet", { replace: true });
        }
    })

    const loginAPi = async (e) => {
        e.preventDefault();

        let item = { loginId, password };
        let result = await fetch("http://localhost:8000/registration");
        const data = await result.json();
        const user = data.find((x) => {
            return x.loginId === item.loginId && x.password === item.password;
        })
        if (!user) {
            setErrors({ err: 'Login or password are not correct' });
        } else {
            localStorage.setItem("user_info", JSON.stringify(user));
            Tweet();
        }
    }
    const signup = (e) => {
        e.preventDefault();
        navigate("../Registration", { replace: true });
    }
    const Tweet = () => {
        navigate("../Tweet", { replace: true });
    }
    return (

        <div className="text-center container d-block mt-4 ">
            <main className="form-signin shadow p-3   bd-blue-300 rounded">
                <svg xmlns="http://www.w3.org/2000/svg" width="72" height="72" fill="#1472b8" className="logo" viewBox="0 0 16 16">
                    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
                </svg>
                <form>
                    <div className={!errors.err ? ' alert alert-danger d-none' : 'alert alert-danger d-block'} role="alert" >
                        {errors.err}
                    </div>
                    <h1 className="h3 mb-3 fw-normal">Please sign in</h1>
                    <div className="form-floating ">
                        <input type="text" className="form-control" name="username" placeholder="username"
                            value={loginId} onChange={(e) => setUserName(e.target.value)} />
                        <label htmlFor="username">User Name</label>

                    </div>
                    <div className="form-floating mt-2">
                        <input type="password" className="form-control" name="password" placeholder="password"
                            value={password} onChange={(e) => setPassword(e.target.value)} />
                        <label htmlFor="password">Password</label>

                    </div>
                    <div className="small text-end ">
                        <Link to="/ResetPassword" className="ml-auto text-secondary">forget password?</Link>
                    </div>
                    <div className="d-flex ">
                        <button className="btn btn-danger me-2 mt-3 w-100" type="submit" onClick={loginAPi} >Sign in</button>
                        <button type="button" className="btn btn-info me-3 mt-3 w-100" onClick={signup}>New User</button>
                    </div>
                </form>
            </main>
        </div>
    )
}
export default Login;