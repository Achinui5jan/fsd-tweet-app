import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ResetPassword = () => {
    const [loginId, setLoginId] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [errors, setErrors] = useState({});

    const navigate = useNavigate();

    const resetAPi = async (e) => {
        e.preventDefault();
        let item = { loginId, email, password, confirmPassword };
        let result = await fetch("http://localhost:8000/registration");
        const data = await result.json();
        const user = data.find((x) => {
            return x.email === item.email && x.loginId === item.loginId;
        })

        if (user === undefined) {
            setErrors({ err: "Email or Login Id not matching" })
        } else {

            user.password = item.password;
            user.confirmPassword = item.confirmPassword;
            await fetch(`http://localhost:8000/registration/${user.id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(user)
            }).then(res => {
                console.log("response: ", res);
                setErrors({ res: "successfully changed" })

            }).catch(err => {
                console.log("errror: ", err);

            });
            setTimeout(() => {
                navigate("../", { replace: true });
            }, 2000)
        }

    }

    return (
        <div className="text-center container d-block mt-4 ">
            <main className="form-signin shadow p-3   bd-blue-300 rounded">
                <div className={!errors.res ? 'd-none' : 'toast align-items-center text-white bg-success border-0 show'} role="alert" aria-live="assertive" aria-atomic="true">
                    <div className="d-flex">
                        <div className="toast-body">
                            Password Succussfully changed!
                    </div>
                        <button type="button" className="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" width="72" height="72" fill="#1472b8" className="logo" viewBox="0 0 16 16">
                    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
                </svg>
                <div className={!errors.err ? ' alert alert-danger d-none' : 'alert alert-danger d-block'} role="alert" >
                    {errors.err}
                </div>
                <form action="" onSubmit={resetAPi}>
                    <h1 className="h3 mb-3 fw-normal">Reset Password</h1>
                    <div className="form-floating mb-2" >
                        <input type="email" className="form-control" name="email" placeholder="email"
                            value={email} onChange={(e) => setEmail(e.target.value)} />
                        <label htmlFor="password">email</label>
                    </div>
                    <div className="form-floating mb-2">
                        <input type="text" className="form-control" name="loginId" placeholder="Login Id"
                            value={loginId} onChange={(e) => setLoginId(e.target.value)} />
                        <label htmlFor="username" >Login Id</label>
                    </div>
                    <div className="form-floating mb-2" >
                        <input type="text" className="form-control" name="password" placeholder="password"
                            value={password} onChange={(e) => setPassword(e.target.value)} />
                        <label htmlFor="password" >password</label>

                    </div>
                    <div className="form-floating mb-2" >
                        <input type="text" className="form-control" name="confirmPassword" placeholder="confirm Password"
                            value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                        <label htmlFor="confirmPassword" >confirm Password</label>

                    </div>
                    <div className="d-flex ">
                        <button className="btn btn-danger mt-3 w-100" type="submit"  >Submit</button>
                    </div>

                </form>
            </main>


        </div>

    )
}
export default ResetPassword;