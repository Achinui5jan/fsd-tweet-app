import React from 'react';
import { Route, Routes } from "react-router-dom";
import Registration from './components/registration';
import Login from './components/login';
import Tweet from './components/twit';
import Nav from './components/nav';

import ResetPassword from "./components/forgottenPassword"
import { BrowserRouter } from 'react-router-dom';

import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/Registration" element={<Registration />} />
        <Route exact path="/ResetPassword" element={<ResetPassword />} />
        <Route exact path="/Tweet" element={<Tweet />} />
        <Route exact path="/Nav" element={<Nav />} />

        <Route exact path="/" element={<Login />} />
      </Routes>
    </BrowserRouter>

  );
}

export default App;
