# Getting Started with Create React App

V////////////////////// Note ///////////////////////////////////
 ### `json-server --watch db.json'            
Runs the fake json server before app on 8000 port in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

after that run this command this will create db.json file if not exist you can change
### `json-server --watch db.json --port 8000' 
Open [http://localhost:8000](http://localhost:8000) to view it in the browser.





This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.




The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.
